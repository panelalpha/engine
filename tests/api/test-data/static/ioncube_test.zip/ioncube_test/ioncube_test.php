<?php
/*
Plugin Name: ionCube Test
Description: Simple plugin to test whether ionCube loader can include/execute an encoded file. Web test via ?ioncube_test=1 and WP-CLI command `wp ioncube_test`.
Version: 1.0
Author: LLM
*/

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Path to the encoded file (relative to this plugin file).
 * Replace encoded_function.php with your actual encoded file.
 */
if ( ! defined( 'IONCUBE_TEST_ENCODED_FILE' ) ) {
	define( 'IONCUBE_TEST_ENCODED_FILE', plugin_dir_path( __FILE__ ) . 'encoded_function.php' );
}

/**
 * Perform the include-and-call test.
 * Returns array: [ 'success' => bool, 'message' => string ]
 */
function ioncube_test_run() {
	$path = IONCUBE_TEST_ENCODED_FILE;

	if ( ! file_exists( $path ) ) {
		return array( 'success' => false, 'message' => "Encoded file not found at: $path" );
	}

	// Suppress warnings/unexpected output from the include to capture failures
	try {
		$fn = @include $path;
	} catch ( Throwable $e ) {
		return array( 'success' => false, 'message' => 'Include threw exception: ' . $e->getMessage() );
	}

	if ( $fn === false ) {
		// include returned false (fatal include failure)
		return array( 'success' => false, 'message' => 'Include returned false — possibly not readable or fatal error during include.' );
	}

	if ( ! is_callable( $fn ) ) {
		return array( 'success' => false, 'message' => 'Included file did not return a callable.' );
	}

	// Call the encoded function and capture return
	try {
		$result = call_user_func( $fn );
	} catch ( Throwable $e ) {
		return array( 'success' => false, 'message' => 'Calling included callable threw exception: ' . $e->getMessage() );
	}

	if ( $result === true ) {
		return array( 'success' => true, 'message' => 'ionCube test passed: included callable executed and returned true.' );
	}

	return array( 'success' => false, 'message' => 'Included callable executed but did not return true (returned: ' . var_export( $result, true ) . ').' );
}

/* --------------------------
   Web test: ?ioncube_test=1
   -------------------------- */
add_action( 'init', function() {
	if ( isset( $_GET['ioncube_test'] ) && intval( $_GET['ioncube_test'] ) === 1 ) {
		$status = ioncube_test_run();

		// Minimal, plain-text output for easy automated checks
		header( 'Content-Type: text/plain; charset=utf-8' );
		if ( $status['success'] ) {
			echo "IONCUBE_TEST: PASS\n";
			echo $status['message'] . "\n";
			exit;
		} else {
			echo "IONCUBE_TEST: FAIL\n";
			echo $status['message'] . "\n";
			exit;
		}
	}
} );

/* --------------------------
   WP-CLI command: wp ioncube_test
   -------------------------- */
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	class Ioncube_Test_Command {
		/**
		 * Run ionCube test.
		 *
		 * ## EXAMPLES
		 *
		 *     wp ioncube_test
		 *
		 */
		public function __invoke( $args, $assoc_args ) {
			$status = ioncube_test_run();
			if ( $status['success'] ) {
				\WP_CLI::success( $status['message'] );
				return 0;
			} else {
				\WP_CLI::error( $status['message'] );
				return 1;
			}
		}
	}

	\WP_CLI::add_command( 'ioncube_test', 'Ioncube_Test_Command' );
}
